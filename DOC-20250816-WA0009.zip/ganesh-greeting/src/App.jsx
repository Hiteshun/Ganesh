import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { Heart, Music, Volume2, VolumeX, Sparkles } from 'lucide-react'
import ganeshaMain from './assets/ganesha-main.jpg'
import ganeshaGreeting from './assets/ganesha-greeting.jpg'
import './App.css'

function App() {
  const [userName, setUserName] = useState('')
  const [showGreeting, setShowGreeting] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)

  const toggleMusic = () => {
    setIsPlaying(!isPlaying)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (userName.trim()) {
      setShowGreeting(true)
    }
  }

  const resetGreeting = () => {
    setShowGreeting(false)
    setUserName('')
  }

  if (showGreeting) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-400 via-red-500 to-pink-500 relative overflow-hidden">
        <Button
          onClick={toggleMusic}
          className="fixed top-4 right-4 z-50 bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white border-white/30"
          size="sm"
        >
          {isPlaying ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </Button>

        <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center relative z-10">
          <div className="animate-bounce mb-8">
            <Sparkles className="w-16 h-16 text-yellow-300 mx-auto mb-4" />
          </div>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl max-w-2xl w-full">
            <CardContent className="p-8">
              <div className="mb-6">
                <img 
                  src={ganeshaMain} 
                  alt="Lord Ganesha" 
                  className="w-48 h-48 object-cover rounded-full mx-auto mb-6 border-4 border-yellow-300 shadow-lg"
                />
              </div>

              <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 animate-pulse">
                🙏 गणपति बप्पा मोरया 🙏
              </h1>

              <h2 className="text-2xl md:text-3xl font-semibold text-yellow-200 mb-6">
                Happy Ganesh Chaturthi
              </h2>

              <div className="bg-white/20 rounded-lg p-6 mb-6">
                <h3 className="text-xl md:text-2xl font-bold text-white mb-4">
                  Dear {userName},
                </h3>
                <p className="text-lg text-white/90 leading-relaxed">
                  May Lord Ganesha remove all obstacles from your path and bless you with wisdom, prosperity, and happiness. 
                  May this auspicious festival bring joy, peace, and success to you and your family.
                </p>
              </div>

              <div className="flex flex-wrap justify-center gap-4 text-2xl mb-6">
                <span className="animate-bounce">🐘</span>
                <span className="animate-bounce">🌺</span>
                <span className="animate-bounce">🪔</span>
                <span className="animate-bounce">🎊</span>
                <span className="animate-bounce">🙏</span>
              </div>

              <div className="text-center">
                <p className="text-lg text-yellow-200 font-semibold mb-4">
                  "गणपति बप्पा मोरया, मंगलमूर्ति मोरया"
                </p>
                <p className="text-white/80">
                  Wishing you a blessed and joyous Ganesh Chaturthi!
                </p>
              </div>

              <Button 
                onClick={resetGreeting}
                className="mt-6 bg-yellow-500 hover:bg-yellow-600 text-orange-900 font-semibold px-8 py-2"
              >
                Create Another Greeting
              </Button>
            </CardContent>
          </Card>

          <div className="mt-8 text-white/60 text-sm">
            <Heart className="w-4 h-4 inline mr-1" />
            Made with devotion for Ganesh Chaturthi
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-600 via-red-600 to-pink-600 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-20 h-20 bg-yellow-400/20 rounded-full animate-pulse"></div>
        <div className="absolute top-32 right-20 w-16 h-16 bg-orange-400/20 rounded-full animate-bounce"></div>
        <div className="absolute bottom-20 left-20 w-24 h-24 bg-pink-400/20 rounded-full animate-pulse"></div>
        <div className="absolute bottom-32 right-10 w-18 h-18 bg-red-400/20 rounded-full animate-bounce"></div>
      </div>

      <Button
        onClick={toggleMusic}
        className="fixed top-4 right-4 z-50 bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white border-white/30"
        size="sm"
      >
        <Music className="w-4 h-4 mr-2" />
        {isPlaying ? 'Playing' : 'Play Music'}
      </Button>

      <div className="flex flex-col items-center justify-center min-h-screen p-4 relative z-10">
        <div className="text-center mb-8">
          <div className="animate-bounce mb-6">
            <img 
              src={ganeshaGreeting} 
              alt="Ganesh Chaturthi" 
              className="w-32 h-32 object-cover rounded-full mx-auto border-4 border-yellow-300 shadow-lg"
            />
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 animate-pulse">
            🙏 गणपति बप्पा मोरया 🙏
          </h1>
          
          <h2 className="text-2xl md:text-3xl font-semibold text-yellow-200 mb-2">
            Happy Ganesh Chaturthi
          </h2>
          
          <p className="text-lg text-white/80 max-w-md mx-auto">
            Create a personalized greeting for this auspicious festival
          </p>
        </div>

        <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl max-w-md w-full">
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-white font-medium mb-2">
                  Enter Your Name
                </label>
                <Input
                  id="name"
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="Your name here..."
                  className="bg-white/20 border-white/30 text-white placeholder-white/60 focus:border-yellow-300"
                  required
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-yellow-500 hover:bg-yellow-600 text-orange-900 font-semibold py-3"
                disabled={!userName.trim()}
              >
                Create My Greeting
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="mt-8 text-center">
          <div className="flex justify-center gap-4 text-3xl mb-4">
            <span className="animate-bounce">🐘</span>
            <span className="animate-bounce">🌺</span>
            <span className="animate-bounce">🪔</span>
            <span className="animate-bounce">🎊</span>
          </div>
          <p className="text-white/60 text-sm">
            <Heart className="w-4 h-4 inline mr-1" />
            Celebrating the festival of new beginnings
          </p>
        </div>
      </div>
    </div>
  )
}

export default App

