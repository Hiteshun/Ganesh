# Ganesh Chaturthi Greeting Website

A beautiful, interactive Ganesh Chaturthi greeting website with personalized messages and festive animations.

## Features

- **Personalized Greetings**: Enter your name to create a custom Ganesh Chaturthi greeting
- **Beautiful Design**: Vibrant gradient backgrounds with festive colors
- **Interactive Elements**: Animated emojis, floating particles, and smooth transitions
- **Responsive Design**: Works perfectly on desktop and mobile devices
- **Music Controls**: Background music toggle for enhanced experience
- **Traditional Elements**: Sanskrit mantras and traditional Ganesh imagery

## Deployment on Vercel

### Option 1: Using Vercel CLI
1. Install Vercel CLI: `npm i -g vercel`
2. Navigate to the project directory
3. Run `vercel` and follow the prompts
4. Your site will be deployed automatically

### Option 2: Using Vercel Dashboard
1. Go to [vercel.com](https://vercel.com)
2. Sign up/login with your GitHub account
3. Click "New Project"
4. Import this repository
5. Vercel will automatically detect it's a React app and deploy it

### Option 3: Manual Upload
1. Build the project: `pnpm run build`
2. Upload the `dist` folder contents to Vercel
3. Configure the project settings if needed

## Local Development

1. Install dependencies: `pnpm install`
2. Start development server: `pnpm run dev`
3. Open http://localhost:5173 in your browser

## Technologies Used

- React 18
- Vite
- Tailwind CSS
- Shadcn/UI Components
- Lucide React Icons
- Framer Motion (for animations)

## Project Structure

```
ganesh-greeting/
├── src/
│   ├── assets/          # Images and static assets
│   ├── components/ui/   # UI components
│   ├── App.jsx         # Main application component
│   ├── App.css         # Styles
│   └── main.jsx        # Entry point
├── dist/               # Built files for deployment
├── public/             # Public assets
├── vercel.json         # Vercel configuration
└── package.json        # Dependencies and scripts
```

## Customization

You can customize the website by:
- Replacing images in `src/assets/`
- Modifying colors and styles in `src/App.jsx`
- Adding new greeting messages
- Updating the Sanskrit mantras
- Adding background music files

## License

This project is open source and available under the MIT License.

---

**गणपति बप्पा मोरया! 🙏**

May Lord Ganesha bless you with happiness, prosperity, and success!

